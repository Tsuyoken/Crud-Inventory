<<<<<<< HEAD
# Crud-Inventory
Project Ujikom Inventory berbasis PHP
=======
<<<<<<< HEAD
# Crud-Inventory
Project Ujikom Inventory berbasis PHP
=======
# Aplikasi Inventaris Barang<br/>
## Free Source Code<br/>

### Aplikasi ini dibuat menggunakan
- Codeigniter 3
- Bootstrap 4
- SB Admin 2 Template
- Datatables
- Chart.js

### Keterangan <br/>
Database : <code>fix.sql</code><br/>
<br/>

